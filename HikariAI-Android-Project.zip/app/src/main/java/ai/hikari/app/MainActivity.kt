package ai.hikari.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF171329)
private val Purple = Color(0xFF8067F2)
private val Panel = Color(0xFF24203B)
private val Muted = Color(0xFFAAA5C4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HikariApp() }
    }
}

data class Character(val name: String, val subtitle: String, val emoji: String)
data class Message(val text: String, val fromUser: Boolean)

@Composable
fun HikariApp() {
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf("Hikari") }
    val characters = listOf(
        Character("Hikari", "Твой универсальный AI-компаньон", "🌸"),
        Character("Акира", "Спокойный собеседник и советчик", "🌙"),
        Character("Рэй", "Любит технологии и игры", "⚡"),
        Character("Мика", "Творчество и идеи", "🎨")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Чат", "Персонажи", "Память", "Профиль").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(listOf(Icons.Default.Chat, Icons.Default.Groups, Icons.Default.Bookmark, Icons.Default.Settings)[i], null) },
                        label = { Text(label) }, colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White, selectedTextColor = Color.White,
                            indicatorColor = Purple, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when(tab) {
                    0 -> ChatScreen(selected)
                    1 -> CharactersScreen(characters, selected) { selected = it; tab = 0 }
                    2 -> MemoryScreen()
                    else -> ProfileScreen()
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        if (subtitle != null) Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun ChatScreen(character: String) {
    var input by remember { mutableStateOf("") }
    val messages = remember(character) { mutableStateListOf(Message("Привет! Я $character 🌸 Чем займёмся сегодня?", false)) }
    Column(Modifier.fillMaxSize()) {
        Header(character, "Hikari AI · онлайн-режим пока демонстрационный")
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if(msg.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(color = if(msg.fromUser) Purple else Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                        Text(msg.text, Modifier.padding(14.dp), color = Color.White, fontSize = 15.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Напиши сообщение…", color = Muted) }, shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Panel, focusedBorderColor = Purple))
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                if(input.isNotBlank()) {
                    val sent = input.trim()
                    messages.add(Message(sent, true))
                    messages.add(Message("Я получил твоё сообщение: «$sent». Сейчас это демо-режим. Для настоящих ответов ИИ нужно подключить серверную AI-модель.", false))
                    input = ""
                }
            }, modifier = Modifier.size(50.dp).background(Purple, CircleShape)) {
                Icon(Icons.Default.Send, null, tint = Color.White)
            }
        }
    }
}

@Composable
fun CharactersScreen(chars: List<Character>, selected: String, onSelect: (String)->Unit) {
    Column {
        Header("Персонажи", "Выбери собеседника")
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(chars) { c ->
                Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { onSelect(c.name) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.emoji, fontSize = 30.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(c.subtitle, color = Muted, fontSize = 12.sp)
                        }
                        if(c.name == selected) Icon(Icons.Default.CheckCircle, null, tint = Purple)
                        else Text("Открыть", color = Purple)
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryScreen() {
    Column {
        Header("Память", "Заметки, которые приложение сможет учитывать")
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Пока нет сохранённых воспоминаний", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("В этой стартовой версии раздел показывает интерфейс. Сохранение истории и синхронизация появятся после подключения хранилища.", color = Muted)
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    Column {
        Header("Настройки", "Hikari AI · версия 1.0")
        listOf("Тема оформления", "Голосовое общение", "Уведомления", "Конфиденциальность", "Подключение AI-сервера").forEach {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, Modifier.weight(1f), color = Color.White)
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
            HorizontalDivider(color = Panel)
        }
        Text("Важно: сейчас это рабочий стартовый интерфейс, а не готовый AI-сервис. Не вводи секретные ключи API в приложение.", Modifier.padding(20.dp), color = Muted, fontSize = 12.sp)
    }
}
